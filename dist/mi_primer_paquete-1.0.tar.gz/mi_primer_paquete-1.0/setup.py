from setuptools import setup

setup(


    name="mi_primer_paquete",
    version="1.0",
    description="primer paquete distribuido",
    author="Nicolás Crudo",
    packages=["paquete"]
)